<!-- Made by winnipeg21 -->

      <!DOCTYPE html>

<html lang="en"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">
  <meta charset="UTF-8">

  <link rel="stylesheet" href="css/app.css">
  <link rel="stylesheet" href="css/animate.css">
  <link href="css/font-awesome.css" rel="stylesheet">

  <style type="text/css">
</style>
</head>
<body>
  <div class="container">
<div class="content">
    <div class="row">
        </div>

      </div>
    </div>
    <div class="row row-centered fadeInUp animated links">
      <div class="col-xs-6 col-centered col-max navigation">
        <h3>Vote1</h3> 
        <center><a href="#"><img src="images/vote.png" alt="v2"></a></center>  <!-- Replace the # with your voting link. -->
      </div>
      <div class="col-xs-6 col-centered col-max navigation">
        <h3>Vote2</h3> 
        <center><a href="#"><img src="images/vote.png" alt="v2"></a></center> <!-- Replace vote.png with the image you want to use! -->
      </div>
      <div class="col-xs-6 col-centered col-max navigation">
        <h3>Vote3</h3> 
        <center><a href="#"><img src="images/vote.png" alt="v2"></a></center>
      </div>
      <div class="col-xs-6 col-centered col-max navigation">
        <h3>Vote4</h3> 
        <center><a href="#"><img src="images/vote.png" alt="v2"></a></center>
      </div>
      <div class="col-xs-6 col-centered col-max navigation">
        <h3>Vote5</h3> 
        <center><a href="#"><img src="images/vote.png" alt="v2"></a></center>
      </div>
    </div>

</div>
</div>
  </body>
</html>